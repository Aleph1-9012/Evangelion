evangelion_cards.module: $(CARDS_SOURCE)
	$(CC) $(DEFS) $(DEFAULT_INCLUDES) $(AM_CPPFLAGS) $(CPPFLAGS_MODULE) $(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS_MODULE) $(CFLAGS) -ffile-prefix-map=$(dir $(CARDS_SOURCE))= -c $< -o $@

evangelion_cards.mod: evangelion_cards.module genmod.sh build-grub-module-verifier
	printf 'evangelion_cards: gfxmenu\n' > cards-moddep.lst
	sh genmod.sh cards-moddep.lst evangelion_cards.module build-grub-module-verifier $@
