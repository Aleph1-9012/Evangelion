#!/usr/bin/env bash
# Rebuild the packaged modules. Development only; users install prebuilt files.
set -euo pipefail
source_dir=$(cd -- "$(dirname -- "$0")" && pwd)
build_dir=${1:?Usage: build.sh /absolute/build-directory}
mkdir -p "$build_dir"
build_dir=$(cd -- "$build_dir" && pwd)
if [[ ! -f $build_dir/grub-2.14/configure ]]; then
    tar -xJf "$source_dir/vendor/grub-2.14.tar.xz" -C "$build_dir"
fi
for target in x86_64-efi i386-pc; do
    mkdir -p "$build_dir/$target" "$build_dir/modules/$target"
    (
        cd "$build_dir/$target"
        if [[ ! -f grub-core/Makefile ]]; then
            ../grub-2.14/configure --with-platform="${target#*-}" --target="${target%-*}" \
                --disable-werror --disable-nls --disable-grub-mkfont --disable-grub-mount \
                --disable-device-mapper --disable-libzfs
        fi
        make -C grub-core -f Makefile -f "$source_dir/module.mk" \
            CARDS_SOURCE="$source_dir/evangelion_cards.c" evangelion_cards.mod
        cp grub-core/evangelion_cards.mod "$build_dir/modules/$target/"
    )
done
printf 'Modules written to %s/modules\n' "$build_dir"
