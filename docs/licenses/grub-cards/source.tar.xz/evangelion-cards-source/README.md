# Evangelion card menu source

This directory contains the corresponding source and build recipe for the
prebuilt `evangelion_cards.mod` files distributed with Soryu. Installing or
using the themes does not require building these files.

The module is licensed under GPL-3.0-or-later. Its viewer setup is derived
from GRUB's `grub-core/gfxmenu/gfxmenu.c`, copyright 2008 Free Software
Foundation, Inc. The custom card component is copyright 2026 Evangelion
contributors. See `COPYING` for the complete license.

The source archive includes the unmodified GNU GRUB 2.14 source distribution in `vendor/`
from https://ftp.gnu.org/gnu/grub/grub-2.14.tar.xz, including its notices and
build scripts. No source download is needed to rebuild the modules.

On an x86 Linux development machine with GCC, GNU make, binutils, Bash,
tar, xz, Bison and Flex, run:

```sh
bash build.sh "$PWD/build"
```

The compiler must support freestanding x86-64 and i386 targets. A 32-bit
libc is not required. The output is `build/modules/x86_64-efi/` and
`build/modules/i386-pc/`. GRUB's module verifier checks both outputs.
The distributed build used GCC 16.2.1 and GNU binutils 2.46. Different
compiler versions can produce different bytes.

`cards.cfg` passes canvas and card geometry, PF2 font names and colors to
the module. The component reads GRUB's real menu model; it does not rewrite
entry titles or boot commands. While the card menu is active, the module
maps Left and Right to GRUB's previous and next entry keys. It restores
the original input callbacks before the editor, command console or entry
execution. Up and Down remain usable. Native GRUB still owns selection,
submenus, the timeout and command execution. Configuration sets the
`evangelion_cards_ready` variable only after initialization succeeds.

The module keeps GRUB's existing graphical menu hook for other themes.
Its card component occupies a named canvas above the static background.
Stock timeout widgets render the timer and hide it when cancelled.
