/* SPDX-License-Identifier: GPL-3.0-or-later
 * Horizontal cards for the native GRUB menu model.
 * Viewer setup follows grub-core/gfxmenu/gfxmenu.c, Copyright 2008 FSF.
 * Copyright 2026 Evangelion contributors.
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3, or any later version.
 * This program is distributed without any warranty, including the implied
 * warranties of merchantability or fitness for a particular purpose.
 * See the GNU General Public License for more details.
 * A copy of the license is supplied with this program in COPYING.
 */
#include <grub/dl.h>
#include <grub/command.h>
#include <grub/env.h>
#include <grub/err.h>
#include <grub/font.h>
#include <grub/gfxmenu_view.h>
#include <grub/gui.h>
#include <grub/menu.h>
#include <grub/menu_viewer.h>
#include <grub/misc.h>
#include <grub/mm.h>
#include <grub/video.h>
#include <grub/color.h>
#include <grub/term.h>

GRUB_MOD_LICENSE ("GPLv3+");

/* All geometry is passed by the generated cards.cfg in design pixels. */
enum { CANVAS_W, CANVAS_H, LEFT, TOP, CARD_W, CARD_H, PITCH, COUNT,
       TEXT_X, TITLE_BASE, LINE_PITCH, INDEX_X, INDEX_BASE, RULE_Y,
       RULE_W, RULE_H, GEOMETRY_COUNT };
static int geometry[GEOMETRY_COUNT];
static grub_font_t menu_font, selected_font, index_font;
static grub_video_rgba_color_t normal_color, selected_color, panel_color;
static grub_gfxmenu_view_t cached_view;
static grub_err_t (*previous_hook) (int, grub_menu_t, int);
static grub_command_t command;
static char *active_theme;

/* grub_error's calling convention changed after 2.12. Set the public error
 * state directly so the same module can run on both supported GRUB versions.
 * GRUB_ERR_BAD_MODULE is 2 in both versions; messages give the precise cause. */
static grub_err_t cards_error (const char *message)
{
  grub_errno = GRUB_ERR_BAD_MODULE;
  grub_strncpy (grub_errmsg, message, GRUB_MAX_ERRMSG - 1);
  grub_errmsg[GRUB_MAX_ERRMSG - 1] = 0;
  return grub_errno;
}

struct cards {
  struct grub_gui_list list;
  grub_gui_container_t parent;
  grub_video_rect_t bounds;
  grub_gfxmenu_view_t view;
  int first;
};

static int px (int value) { return (value * geometry[CANVAS_W] + 1920) / 3840; }

static void destroy (void *self) { grub_free (self); }
static const char *get_id (void *self __attribute__((unused))) { return "__menu__"; }
static int is_instance (void *self __attribute__((unused)), const char *type)
{ return !grub_strcmp (type, "component") || !grub_strcmp (type, "list"); }
static void set_parent (void *self, grub_gui_container_t parent)
{ ((struct cards *) self)->parent = parent; }
static grub_gui_container_t get_parent (void *self)
{ return ((struct cards *) self)->parent; }
static void set_bounds (void *self, const grub_video_rect_t *bounds)
{ ((struct cards *) self)->bounds = *bounds; }
static void get_bounds (void *self, grub_video_rect_t *bounds)
{ *bounds = ((struct cards *) self)->bounds; }
static grub_err_t set_property (void *self __attribute__((unused)),
                               const char *name __attribute__((unused)),
                               const char *value __attribute__((unused)))
{ return GRUB_ERR_NONE; }
static void set_view (void *self, grub_gfxmenu_view_t view)
{ ((struct cards *) self)->view = view; }
static void refresh (void *self, grub_gfxmenu_view_t view)
{ struct cards *cards = self; cards->view = view; cards->first = 0; }

/* Wrap at word boundaries; split long words only on UTF-8 boundaries.
 * The title is copied for drawing and the boot entry itself is unchanged. */
static void draw_title (const char *title, grub_font_t font,
                        grub_video_color_t color, int width, int selected)
{
  char *copy = grub_strdup (title), *cursor, *start, *last_space;
  char *lines[16];
  int count = 0, step = px (geometry[LINE_PITCH]);
  int baseline = px (geometry[TITLE_BASE]), i;
  if (!copy) return;
  /* PF2 ascent includes tall fallback glyphs. Use the design's line spacing
   * so ordinary selected titles retain room for four wrapped lines. */
  if (selected) step = grub_max (step + 1, step * 4 / 3);
  cursor = copy;
  while (*cursor && count < 16) {
    while (*cursor == ' ' || *cursor == '\t' || *cursor == '\n') cursor++;
    if (!*cursor) break;
    start = cursor; last_space = 0;
    while (*cursor) {
      char *next = cursor + 1, saved;
      while ((*next & 0xc0) == 0x80) next++;
      if (*cursor == ' ' || *cursor == '\t') last_space = cursor;
      saved = *next; *next = 0;
      int fits = grub_font_get_string_width (font, start) <= width;
      *next = saved;
      if (!fits && cursor > start) {
        if (last_space && last_space > start) { *last_space = 0; cursor = last_space + 1; }
        else {
          /* Retain the split code point by moving the suffix into a new
           * allocation below; the common word-wrap case needs no copy. */
          char *tail = grub_strdup (cursor);
          *cursor = 0;
          lines[count++] = grub_strdup (start);
          grub_free (copy); copy = tail; cursor = copy;
          if (!copy) goto done;
          start = 0;
        }
        break;
      }
      cursor = next;
    }
    if (start) lines[count++] = grub_strdup (start);
  }
  /* Keep the number area clear even for unusually long entry titles. */
  {
    int max_lines = (baseline - px (geometry[INDEX_BASE] + 70)) / step + 1;
    int visible = grub_min (count, grub_max (1, max_lines));
    if (visible && (count > visible || *cursor) && lines[visible-1]) {
      grub_size_t length = grub_strlen (lines[visible-1]);
      char *last = grub_malloc (length + 4);
      if (last) {
        grub_memmove (last, lines[visible-1], length);
        for (;;) {
          grub_memmove (last + length, "...", 4);
          if (grub_font_get_string_width (font, last) <= width || !length) break;
          do { length--; } while (length && (last[length] & 0xc0) == 0x80);
        }
        grub_free (lines[visible-1]); lines[visible-1] = last;
      }
    }
    for (i = 0; i < visible; i++)
      if (lines[i]) grub_font_draw_string (lines[i], font, color,
          px (geometry[TEXT_X]), baseline - (visible - i - 1) * step);
  }
done:
  for (i = 0; i < count; i++) grub_free (lines[i]);
  grub_free (copy);
}

static void paint (void *self, const grub_video_rect_t *region)
{
  struct cards *cards = self;
  grub_gfxmenu_view_t view = cards->view;
  grub_video_rect_t old, card, saved;
  int slot, columns = geometry[COUNT];
  if (!view || !grub_video_have_common_points (region, &cards->bounds)) return;
  if (view->selected < cards->first) cards->first = view->selected;
  if (view->selected >= cards->first + columns) cards->first = view->selected - columns + 1;
  grub_gui_set_viewport (&cards->bounds, &old);
  for (slot = 0; slot < columns && cards->first + slot < view->menu->size; slot++) {
    int index = cards->first + slot, selected = index == view->selected;
    grub_menu_entry_t entry = grub_menu_get_entry (view->menu, index);
    grub_video_color_t color = grub_video_map_rgba_color (selected ? selected_color : normal_color);
    char number[24];
    card.x = px (slot * geometry[PITCH]); card.y = 0;
    card.width = px (geometry[CARD_W]); card.height = px (geometry[CARD_H]);
    grub_gui_set_viewport (&card, &saved);
    if (selected) grub_video_fill_rect (grub_video_map_rgba_color (panel_color), 0, 0, card.width, card.height);
    grub_snprintf (number, sizeof (number), "%02d", index + 1);
    grub_font_draw_string (number, index_font, color, px (geometry[INDEX_X]), px (geometry[INDEX_BASE]));
    draw_title (entry->title, selected ? selected_font : menu_font, color,
                card.width - 2 * px (geometry[TEXT_X]), selected);
    grub_video_fill_rect (color, px (geometry[TEXT_X]), px (geometry[RULE_Y]),
                          px (geometry[RULE_W]), grub_max (1, px (geometry[RULE_H])));
    grub_gui_restore_viewport (&saved);
  }
  grub_gui_restore_viewport (&old);
}

static struct grub_gui_component_ops component_ops = {
  .destroy = destroy, .get_id = get_id, .is_instance = is_instance,
  .paint = paint, .set_parent = set_parent, .get_parent = get_parent,
  .set_bounds = set_bounds, .get_bounds = get_bounds, .set_property = set_property
};
static struct grub_gui_list_ops list_ops = { .set_view_info = set_view, .refresh_list = refresh };

static void find_host (grub_gui_component_t component, void *data)
{
  if (component->ops->is_instance (component, "container"))
    *(grub_gui_container_t *) data = (grub_gui_container_t) component;
}

static grub_err_t add_cards (grub_gfxmenu_view_t view)
{
  struct cards *cards = grub_zalloc (sizeof (*cards));
  grub_gui_component_t component;
  grub_gui_container_t host = 0;
  if (!cards) return grub_errno;
  grub_gui_find_by_id ((grub_gui_component_t) view->canvas, "evangelion-cards", find_host, &host);
  if (!host) { grub_free (cards); return cards_error ("Missing card canvas"); }
  cards->list.ops = &list_ops; cards->view = view;
  component = &cards->list.component; component->ops = &component_ops;
  component->xfrac = component->yfrac = GRUB_FIXED_1 / 2;
  component->x = px (geometry[LEFT]) - geometry[CANVAS_W] / 2;
  component->y = px (geometry[TOP]) - geometry[CANVAS_H] / 2;
  component->w = px ((geometry[COUNT] - 1) * geometry[PITCH] + geometry[CARD_W]);
  component->h = px (geometry[CARD_H]);
  host->ops->add (host, component);
  return grub_errno;
}

/* GRUB normally treats Right as Enter. Translate horizontal arrows only
 * while this menu viewer is active; command/editor cursor keys stay native. */
struct card_input {
  struct card_input *next;
  grub_term_input_t term;
  int (*getkey) (grub_term_input_t);
};
static struct card_input *card_inputs;

static int card_getkey (grub_term_input_t term)
{
  struct card_input *input;
  for (input = card_inputs; input; input = input->next)
    if (input->term == term) {
      int key = input->getkey (term);
      if (key == GRUB_TERM_KEY_RIGHT) return GRUB_TERM_KEY_DOWN;
      if (key == GRUB_TERM_KEY_LEFT) return GRUB_TERM_KEY_UP;
      return key;
    }
  return GRUB_TERM_NO_KEY;
}

static void viewer_fini (void *data __attribute__((unused)))
{
  while (card_inputs) {
    struct card_input *input = card_inputs;
    card_inputs = input->next;
    if (input->term->getkey == card_getkey)
      input->term->getkey = input->getkey;
    grub_free (input);
  }
}

static grub_err_t install_card_keys (void)
{
  grub_term_input_t term;
  struct card_input *input;
  /* A refresh must never wrap our own callback. */
  viewer_fini (0);
  FOR_ACTIVE_TERM_INPUTS (term) {
    input = grub_malloc (sizeof (*input));
    if (!input) { viewer_fini (0); return grub_errno; }
    input->term = term; input->getkey = term->getkey;
    input->next = card_inputs; card_inputs = input;
  }
  for (input = card_inputs; input; input = input->next)
    input->term->getkey = card_getkey;
  return GRUB_ERR_NONE;
}

static grub_err_t try_cards (int selected, grub_menu_t menu, int nested)
{
  const char *theme = grub_env_get ("theme");
  struct grub_video_mode_info mode;
  struct grub_menu_viewer *viewer;
  grub_gfxmenu_view_t view;
  if (!active_theme || !theme || grub_strcmp (theme, active_theme)) return previous_hook ? previous_hook (selected, menu, nested) : GRUB_ERR_BAD_ARGUMENT;
  if (grub_video_get_info (&mode)) return grub_errno;
  if (mode.width < (unsigned)geometry[CANVAS_W] || mode.height < (unsigned)geometry[CANVAS_H])
    return cards_error ("Display is smaller than the card design");
  viewer = grub_zalloc (sizeof (*viewer));
  if (!viewer) return grub_errno;
  if (!cached_view || grub_strcmp (cached_view->theme_path, theme) ||
      cached_view->screen.width != mode.width || cached_view->screen.height != mode.height) {
    grub_gfxmenu_view_destroy (cached_view); cached_view = 0;
    cached_view = grub_gfxmenu_view_new (theme, mode.width, mode.height);
    if (!cached_view || add_cards (cached_view)) {
      grub_gfxmenu_view_destroy (cached_view); cached_view = 0;
      grub_free (viewer); return grub_errno;
    }
  }
  view = cached_view;
  view->double_repaint = (mode.mode_type & GRUB_VIDEO_MODE_TYPE_DOUBLE_BUFFERED) &&
                        !(mode.mode_type & GRUB_VIDEO_MODE_TYPE_UPDATING_SWAP);
  view->selected = selected; view->menu = menu; view->nested = nested; view->first_timeout = -1;
  grub_video_set_viewport (0, 0, mode.width, mode.height);
  if (view->double_repaint) { grub_video_swap_buffers (); grub_video_set_viewport (0, 0, mode.width, mode.height); }
  grub_gfxmenu_view_draw (view);
  if (install_card_keys ()) { grub_free (viewer); return grub_errno; }
  viewer->data = view; viewer->fini = viewer_fini;
  viewer->set_chosen_entry = grub_gfxmenu_set_chosen_entry;
  viewer->print_timeout = grub_gfxmenu_print_timeout; viewer->clear_timeout = grub_gfxmenu_clear_timeout;
  grub_menu_register_viewer (viewer);
  return GRUB_ERR_NONE;
}

static grub_font_t named_font (const char *name)
{
  grub_font_t font = grub_font_get (name);
  const char *actual = font ? grub_font_get_name (font) : 0;
  return actual && !grub_strcmp (actual, name) ? font : 0;
}

static grub_err_t configure (grub_command_t cmd __attribute__((unused)), int argc, char **argv)
{
  int i, next[GEOMETRY_COUNT];
  grub_font_t next_menu, next_selected, next_index;
  grub_video_rgba_color_t next_normal, next_text, next_panel;
  const char *theme;
  char *next_theme;
  if (argc != GEOMETRY_COUNT + 6) return cards_error ("Invalid card menu configuration");
  for (i = 0; i < GEOMETRY_COUNT; i++) {
    const char *end;
    unsigned long value = grub_strtoul (argv[i], &end, 10);
    if (grub_errno || *end || value > 16384) return cards_error ("Invalid card geometry");
    next[i] = value;
  }
  if (next[CANVAS_W] < 640 || next[CANVAS_H] < 480 ||
      !next[CARD_W] || !next[CARD_H] || !next[LINE_PITCH] ||
      next[COUNT] < 1 || next[COUNT] > 16)
    return cards_error ("Empty card geometry");
  if (next[LEFT] + (next[COUNT]-1)*next[PITCH] + next[CARD_W] > 3840 ||
      next[TOP] + next[CARD_H] > 2160 || next[PITCH] < next[CARD_W] ||
      next[TEXT_X]*2 >= next[CARD_W] ||
      (next[LINE_PITCH]*next[CANVAS_W]+1920)/3840 < 1)
    return cards_error ("Card geometry exceeds the design");
  next_menu = named_font (argv[GEOMETRY_COUNT]);
  next_selected = named_font (argv[GEOMETRY_COUNT + 1]);
  next_index = named_font (argv[GEOMETRY_COUNT + 2]);
  if (!next_menu || !next_selected || !next_index) return cards_error ("Missing card menu fonts");
  if (grub_video_parse_color (argv[GEOMETRY_COUNT + 3], &next_normal) ||
      grub_video_parse_color (argv[GEOMETRY_COUNT + 4], &next_text) ||
      grub_video_parse_color (argv[GEOMETRY_COUNT + 5], &next_panel)) return grub_errno;
  theme = grub_env_get ("theme");
  if (!theme) return cards_error ("Missing card theme");
  next_theme = grub_strdup (theme);
  if (!next_theme) return grub_errno;
  /* Commit only a complete valid configuration. A failed command must not
   * corrupt an existing viewer's geometry or font pointers. */
  for (i = 0; i < GEOMETRY_COUNT; i++) geometry[i] = next[i];
  menu_font = next_menu; selected_font = next_selected; index_font = next_index;
  normal_color = next_normal; selected_color = next_text; panel_color = next_panel;
  grub_free (active_theme); active_theme = next_theme;
  grub_gfxmenu_view_destroy (cached_view); cached_view = 0;
  grub_gfxmenu_try_hook = try_cards;
  return grub_env_set ("evangelion_cards_ready", "1");
}

GRUB_MOD_INIT (evangelion_cards)
{
  previous_hook = grub_gfxmenu_try_hook;
  command = grub_register_command ("evangelion_cards", configure, "GEOMETRY FONTS COLORS", "Enable the Evangelion card menu.");
  grub_dl_ref (mod);
}
GRUB_MOD_FINI (evangelion_cards)
{
  viewer_fini (0);
  if (grub_gfxmenu_try_hook == try_cards) grub_gfxmenu_try_hook = previous_hook;
  grub_unregister_command (command);
  grub_free (active_theme);
  grub_gfxmenu_view_destroy (cached_view);
}
